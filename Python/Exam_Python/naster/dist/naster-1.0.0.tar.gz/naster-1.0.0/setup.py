from distutils.core import setup

setup(
    name = 'naster',
    version = '1.0.0',
    py_modules = ['naster'],
    author = 'sun',
    author_email = 'dkdkdkdkd.com',
    url = 'ddhtl',
    description = 'the_list',
)
